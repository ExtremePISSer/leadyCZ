var request = require('request');
var cheerio = require('cheerio');

//COMPANY NAME ve funkci GET_Data
function getData(companyName, callback) {
    request(`https://or.justice.cz/ias/ui/rejstrik-dotaz?dotaz=${encodeURIComponent(companyName)}`, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            let results = [];
            $ = cheerio.load(body);
            $(".search-results li.result").each(function (i, elem) {
                var company = {};
                $(elem).find("th").each(function (j, cell) {
                    var key = $(cell).text().trim();
                    company[key] = $(cell).next().text().trim();
                });
                results.push(company);
            });
            callback(results);
            console.log("#results##");
            console.log(JSON.stringify(results));
            console.log("#results##");
        }
    });
}

NAZEVspolecnosti = "jones lang";

getData(NAZEVspolecnosti, function(data) {
    data = JSON.stringify(data);
    console.log(data);
});