document.getElementById('getTextbutton').addEventListener
('click', getText);

function getText(){

             fetch('sample.txt')

        .then((res) => res.text())
        .then((data) => {
            document.getElementById('vysledek').innerHTML = data;
        })
        .catch((err) => console.log(err));
        }

